create table notice (
    nno         int             auto_increment,
    title       varchar(50)     not null,
    contents    text            not null,
    userid      varchar(20)     not null,
    views       int             default 0,
    thumbs      int             default 0,
    regdate     datetime        default current_timestamp,
    primary key (nno)
);

create table noticeattach (
    nano        int             auto_increment,
    nno         int             not null,
    nname       varchar(200)    not null,
    ntype       varchar(3)      not null,
    nsize       float           not null,
    ndown       int             default 0,
    primary key (nano)
);

alter table noticeattach add constraint fknno foreign key (nno) references notice (nno);
alter table noticeattach drop foreign key fknno;
alter table noticeattach add constraint fknno foreign key (nno) references notice (nno)
ON DELETE CASCADE;

create view nna as select * from notice n join noticeattach na using (nno);
select * from nna where nno='45';

insert into notice (title, contents, userid)
values ('빌드가 731ms에서 성공적으로 완료되었습니다! (1분 전)', '빌드가 731ms에서 성공적으로 완료되었습니다! (1분 전)', 'admin');


create table member (
    mno         int             auto_increment,
    username    varchar(20)     not null,
    userid      varchar(20)     unique,
    passwd      varchar(20)     not null,
    phone       varchar(20)     not null,
    email       varchar(20)     not null,
    zipcode     char(7)         not null,
    addr1       varchar(100)    not null,
    addr2       varchar(100)    not null,
    regdate     datetime        default current_timestamp,
    primary key (mno)
);


insert into member (username, userid, passwd, phone, email, zipcode, addr1, addr2)
values ('관리자', 'admin', 'admin', '010-1234-1234', 'admin@admin.com', '123456', '서울 관악구', '블라블라');

select * from member;

create table perfume (
    pno         int             auto_increment,
    name       varchar(20)     not null,
    brand       varchar(20)     not null,
    volume      varchar(10)     not null,
    price       varchar(10)     not null,
    sales       int             not null,
    image       blob            not null,
    primary key (pno)
);

create table perfumeattach (
    pano        int                 auto_increment,
    pno         int                 not null,
    pname       varchar(1024)       not null,
    psize       varchar(256)        not null,
    primary key (pano)
);

alter table perfumeattach add constraint fkpano foreign key (pno) references perfume(pno);

select AUTO_INCREMENT -1 pno from information_schema.TABLES where TABLE_NAME = 'perfume';

select * from perfume p join perfumeattach pa using (pno) where p.pno='3';
create view ppa as select * from perfume p join perfumeattach pa using (pno);
select * from ppa where pno='3';


create table board (
    bno         int             auto_increment,
    title       varchar(20)     not null,
    contents    varchar(100)    not null,
    userid      varchar(20)     unique,
    regdate     datetime        default current_timestamp,
    primary key (bno)
);


create table orders (
    ono         int             auto_increment,
    userid      varchar(10)     not null,
    regdate     datetime        default current_timestamp,
    primary key (ono)
);
create table order_detail(
    odno        int             auto_increment,
    orderno     int,
    pfno        int,
    qunantity   int(5)          not null,
    result      char(1),
    primary key (odno)
);
drop table order_detail;
alter table order_detail add constraint fkodno foreign key (orderno) references orders (ono);
alter table order_detail add constraint fkpf foreign key (pfno) references perfume (pno);

alter table board add constraint fkuserid1 foreign key (userid) references member (userid);
alter table notice add constraint fkuserid2 foreign key (userid) references member (userid) ON DELETE CASCADE;
alter table orders add constraint fkuserid3 foreign key (userid) references member (userid) ON DELETE CASCADE;
alter table notice add constraint fkuserid2 foreign key (userid) references member (userid);
alter table orders add constraint fkuserid3 foreign key (mno) references member (mno);
alter table notice add constraint fkuserid2 foreign key (userid) references member (userid) ON DELETE CASCADE;
alter table orders add constraint fkuserid3 foreign key (userid) references member (userid) ON DELETE CASCADE;

create table ncomment (
        cno         int             auto_increment,
        conmment    text            not null,
        userid      varchar(20)     not null,
        regdate     datetime        default current_timestamp,
        nno         int             not null,
        ref         int             not null,
        primary key (cno)
);

alter table ncomment add constraint fkuid foreign key (userid) references member(userid) ON DELETE CASCADE;
alter table ncomment add constraint fkrefcno foreign key (ref) references ncomment (cno);
alter table ncomment add constraint fkpnocno foreign key (nno) references notice(nno);


create table cart(
    cno         int             auto_increment,
    mno         int             not null,
    pno         int             not null,
    quantity    int             not null,
    regdate     datetime        default current_timestamp,
    primary key(cno)
);
alter table cart add constraint fkmnocart foreign key (mno) references member (mno) ON DELETE CASCADE;
alter table cart add constraint fkmnocart foreign key (mno) references  member(mno);
alter table cart add constraint fkpnocart foreign key (pno) references perfume (pno);
alter table cart add constraint fkmnocart foreign key (mno) references member (mno) ON DELETE CASCADE;
/*alter table cart add constraint fkpnocart foreign key (pno) references perfume (pno);*/

insert into perfume (name, brand, volume, price, image) values('오드 뚜 왈렛','chanel','100ml','19,999,000','1212');

create or replace view order_view
as
select d.odno, o.ono, o.mno, o.regdate, d.pfno, d.quantity, m.username,
       m.zipcode, m.addr1,m.addr2, m.phone, p.name, p.price, pa.pname , d.result
from orders o join order_detail d on o.ono = d.orderno join member m using (mno) join perfumeattach pa
    join perfume p on d.pfno = p.pno;

create or replace view order_view
as
select d.odno, o.ono, o.mno, o.regdate, d.pfno, d.quantity, m.username,
       m.zipcode, m.addr1,m.addr2, m.phone, p.name, p.price, pa.pname , d.result
from orders o, order_detail d, member m, perfumeattach pa, perfume p
    where o.ono = d.orderno and o.mno = m.mno and d.pfno = p.pno and p.pno = pa.pno;

select * from order_view;

create or replace view cart_view
as
select c.cno, c.mno, c.pno, m.username mname, p.name pname,
       c.quantity, c.regdate, p.price
from cart c, member m, perfume p
where c.mno = m.userid and c.pno = p.pno;

insert into cart (mno, pno, quantity) values('admin','17','5');

create table pcomment (
      cno         int             auto_increment,
      pno         int             not null,
      comment    text            not null,
      userid      varchar(20)     not null,
      regdate     datetime        default current_timestamp,
      primary key (cno)
);
alter table pcomment add constraint fkuid2 foreign key (userid) references member(userid) ON DELETE CASCADE;
alter table pcomment add constraint fkpnocno2 foreign key (pno) references perfume(pno);

create table pquestion (
      qno         int             auto_increment,
      pno         int             not null,
      comment    text            not null,
      userid      varchar(20)     not null,
      regdate     datetime        default current_timestamp,
      primary key (qno)
);

alter table pquestion add constraint fkuid3 foreign key (userid) references member(userid) ON DELETE CASCADE;
alter table pquestion add constraint fkpnoqno foreign key (pno) references perfume(pno);

