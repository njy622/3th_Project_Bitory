package com.perfume;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfumeProjectV1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
