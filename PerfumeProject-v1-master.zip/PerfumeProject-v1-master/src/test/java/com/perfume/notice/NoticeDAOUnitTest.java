package com.perfume.notice;

import com.perfume.dao.NoticeDAO;
import com.perfume.dao.NoticeDAOImpl;
import com.perfume.model.Notice;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(NoticeDAOImpl.class)
public class NoticeDAOUnitTest {

    @Autowired
    private NoticeDAO ndao;

    @Test
    @DisplayName("NoticeDAO select Test")
    void selectNotice() {
        int cpg=1;
        int stnum=(cpg-1)*10;
        List<Notice> results=ndao.selectNotice(stnum);
        assertNotNull(results);
    }

//    @Test
//    @DisplayName("NoticeDAO insert Test")
//    void insertNotice() {
//        Notice n= new Notice(null, "비가 오지 않습니다.", "비가 오지 않습니다.", "admin", "", "", null);
//        int result=ndao.insertNotice(n);
//        System.out.println(result);
//        assertEquals(result, 1);
//    }

}
