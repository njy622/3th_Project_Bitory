package com.perfume.notice;

import com.perfume.model.Notice;
import com.perfume.mybatis.NoticeMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class NoticeMapperUnitTest {
    @Autowired
    private NoticeMapper noticeMapper;
    @Test
    @DisplayName("NoticeMapper selectNotice Test")
    void selectBoard() {
        int cpg=1;
        int stnum=(cpg-1)*10;
        List<Notice> results=noticeMapper.selectNotice(stnum);
        assertNotNull(results);
    }
//    @Test
//    @DisplayName("NoticeMapper insert Test")
//    @Transactional
//    void insertNotice() {
//        Notice n=new Notice(null, "비가 오지 않습니다.", "비가 오지 않습니다.", "admin", "", "", null);
//        int result=noticeMapper.insertNotice(n);
//        System.out.println(result);
//        assertEquals(result,1);
//    }
/*    @Test
    @DisplayName("NoticeMapper selectOneBoard Test")
    void selectOneBoard() {
        String nno="10";
        Notice result=noticeMapper.selectOneNotice(nno);
        System.out.println(result);
        assertNotNull(result);
    }*/

/*    @Test
    @DisplayName("NoticeMapper deleteNotice Test")
    @Transactional
    void deleteOneBoard() {
        String nno="10";
        int result=noticeMapper.deleteNotice(nno);
        assertEquals(result, 1);
    }*/

    @Test
    @DisplayName("NoticeMapper find Test")
    void find() {
        Map<String, Object> params=new HashMap<>();
            params.put("findtype", "title");
            params.put("findkey", "오후");
            params.put("stnum", 0);

        List<Notice> results=noticeMapper.findNotice(params);
        assertNotNull(results);
    }
}
