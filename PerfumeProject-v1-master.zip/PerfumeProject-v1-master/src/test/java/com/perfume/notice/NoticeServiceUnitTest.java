package com.perfume.notice;

import com.perfume.dao.NoticeDAOImpl;
import com.perfume.model.Notice;
import com.perfume.service.NoticeService;
import com.perfume.service.NoticeServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import({NoticeServiceImpl.class, NoticeDAOImpl.class})
public class NoticeServiceUnitTest {

    @Autowired
    private NoticeService nsrv;

/*    @Test
    @DisplayName("NoticeService read Test")
    void readNotice() {
        int cpg=1;
        List<Notice> results=nsrv.readNotice(cpg);
        assertNotNull(results);
    }*/

//    @Test
//    @DisplayName("NoticeService save Test")
//    void saveNotice() {
//        Notice n=new Notice(null, "비가 오지 않습니다.", "비가 오지 않습니다.", "admin", "", "", null);
//        int result=nsrv.saveNotice(n);
//        System.out.println(result);
//        assertEquals(result, true);
//    }
}
