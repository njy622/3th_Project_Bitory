package com.perfume.order;

import com.perfume.dao.OrderDAO;
import com.perfume.model.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class OrderDAOUnitTest {
    @Autowired
    private OrderDAO odao;

    @Test
    @DisplayName("OrderDAO insert Test")
    @Transactional
    void insertOrders() {
        int mno = 1;
        int result = odao.insertOrders(mno);
        assertNotNull(result);
    }

    @Test
    @DisplayName("OrderDAO insertDetail Test")
    void insertDetail() {
        Order_Detail detail = new Order_Detail();
        detail.setQuantity("2");
        int result = odao.insertOrder_Detail(detail);
        assertNotNull(result);
    }
    @Test
    @DisplayName("OrderDAO selectOrder_View Test")
    void selectOrder_View(){
    }
/*    @Test
    @DisplayName("OrderDAO insertCart Test")
    @Transactional
    void insertCart() {
        Cart c = new Cart();
        c.setPno("21");
        c.setMno("1");
        int result = odao.insertCart(c);
        assertNotNull(result);
    }*/
    @Test
    @DisplayName("OrderDAO select Test")
    void selectCart_View(){
        int mno = 1;
        List results = odao.selectCart_View(mno);

        System.out.println(results);
        assertNotNull(results);
    }


}
