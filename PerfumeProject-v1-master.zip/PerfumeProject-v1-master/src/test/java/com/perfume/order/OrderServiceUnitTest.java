package com.perfume.order;

import com.perfume.model.Cart;
import com.perfume.model.Cart_View;
import com.perfume.model.Order_View;
import com.perfume.service.OrderService;
import com.perfume.service.OrderServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class OrderServiceUnitTest {
    @Autowired
    private OrderService osrv;

    @Test
    @DisplayName("Order readOrder_View Test")
    void readOrder_View() {
        List<Order_View> results = osrv.readOrder_View(1);
        assertNotNull(results);
    }
/*    @Test
    @DisplayName("Order readCart_View Test")
    void readCart_View() {
        int mno = 1;
        List<Cart_View> results = osrv.readCart_View(mno);
        assertNotNull(results);
    }*/
/*    @Test
    @DisplayName("OrderService saveCart Test")
    @Transactional
    void saveCart() {
        Cart c = new Cart();
        c.setPno("21");
        c.setMno("1");
        boolean result = osrv.saveCart(c);
        assertNotNull(result);
    }*/
}
