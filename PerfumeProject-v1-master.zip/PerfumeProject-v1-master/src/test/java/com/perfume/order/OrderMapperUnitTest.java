package com.perfume.order;

import com.perfume.model.*;
import com.perfume.mybatis.OrderMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class OrderMapperUnitTest {

    @Autowired
    private OrderMapper orderMapper;

    @Test
    @DisplayName("OrderMapper insert Test")
    @Transactional
    void insertOrder() {
        int result = orderMapper.insertOrders(1);
        assertNotNull(result);
    }
    @Test
    @DisplayName("OrderMapper insertDetail Test")
    @Transactional
    void insertDetail() {
        Order_Detail detail = new Order_Detail();
        detail.setQuantity("12");
        int result = orderMapper.insertOrder_Detail(detail);
        assertNotNull(result);
    }
/*    @Test
    @DisplayName("OrderMapper select Test")
    void selectOrder_view(){
        int mno = 1;
        List results = orderMapper.selectOrder_View(mno);

        System.out.println(results);
        assertEquals(results,null);
    }*/

/*    @Test
    @DisplayName("OrderMapper insert Test")
    @Transactional
    void insertCart() {
        Perfume pf = new Perfume();
        .setQuantity("12");
        c.setUserid("admin");
        c.setPno("7");
        int result = orderMapper.insertCart(c);
        assertNotNull(result);
    }*/
    @Test
    @DisplayName("OrderMapper select Test")
    void selectCart_View(){
        int mno = 3;
        List<Cart_View> results = orderMapper.selectCart_View(mno);

        System.out.println(results);
        assertNotNull(results);
    }
}
