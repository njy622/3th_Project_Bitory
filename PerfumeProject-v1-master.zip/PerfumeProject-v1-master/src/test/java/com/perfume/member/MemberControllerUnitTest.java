package com.perfume.member;

import com.perfume.model.Member;
import com.perfume.mybatis.MemberMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class MemberControllerUnitTest {
    @Autowired
    private MockMvc mvc;

    @Test
    @DisplayName("MemberController save Test")
    @Transactional
    void saveMember() throws Exception {
        mvc.perform(post("/member/join")
                .param("username","관리자")
                .param("userid","admin123")
                .param("passwd","")
                .param("phone","")
                .param("email","admin@admin.com")
                .param("zipcode","123456")
                .param("addr1","서울 관악구")
                .param("addr2","블라블라"))
                .andExpect(status().is3xxRedirection())
                .andDo(print());

    }

    @Test
    @DisplayName("MemberController login Test")
    void login() throws Exception {
        mvc.perform(post("/member/login")
                .param("userid","admin")
                .param("passwd","admin"))
                .andExpect(status().is3xxRedirection())
                .andDo(print());

    }
}