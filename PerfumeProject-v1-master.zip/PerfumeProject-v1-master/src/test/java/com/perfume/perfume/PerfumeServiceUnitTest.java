package com.perfume.perfume;

import com.perfume.dao.NoticeDAOImpl;
import com.perfume.dao.PerfumeDAOImpl;
import com.perfume.model.Notice;
import com.perfume.model.Perfume;
import com.perfume.service.NoticeService;
import com.perfume.service.NoticeServiceImpl;
import com.perfume.service.PerfumeService;
import com.perfume.service.PerfumeServiceImpl;
import com.perfume.utils.Perutils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import({PerfumeServiceImpl.class, PerfumeDAOImpl.class, Perutils.class})
public class PerfumeServiceUnitTest {

    @Autowired
    private PerfumeService psrv;

    @Test
    @DisplayName("Perfume category Test")
    void category() {
        String param = "샤넬";
        List<Perfume> results = psrv.category(param);
        assertNotNull(results);
    }


}
