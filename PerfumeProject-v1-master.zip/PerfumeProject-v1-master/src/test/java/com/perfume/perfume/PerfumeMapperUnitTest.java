package com.perfume.perfume;

import com.perfume.model.Notice;
import com.perfume.model.PComment;
import com.perfume.model.Perfume;
import com.perfume.mybatis.NoticeMapper;
import com.perfume.mybatis.PerfumeMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class PerfumeMapperUnitTest {
    @Autowired
    private PerfumeMapper perfumeMapper;

    @Test
    @DisplayName("BoardMapper count Test")
    void count() {
        int result=perfumeMapper.countPage();
        System.out.println(result);
        assertNotNull(result);
    }
    @Test
    @DisplayName("Perfume category Test")
    void category() {
        String param = "샤넬";
        List<Perfume> results = perfumeMapper.category(param);
        assertNotNull(results);
    }
    @Test
    @DisplayName("PerfumeMapper comment Test")
    @Transactional
    void comment() {
        PComment pc=new PComment();
        pc.setUserid("admin");
        pc.setComment("테스트");
        pc.setPno("24");

        int result=perfumeMapper.insertComment(pc);
        assertNotNull(result);
    }

    @Test
    @DisplayName("PerfumeMapper read Test")
    @Transactional
    void read() {
        PComment pc=new PComment();
        pc.setPno("24");

        List<PComment> results=perfumeMapper.selectComment(pc);
        System.out.println(results);
        assertNotNull(results);
    }
}
