package com.perfume.perfume;

import com.perfume.dao.NoticeDAO;
import com.perfume.dao.NoticeDAOImpl;
import com.perfume.dao.PerfumeDAO;
import com.perfume.dao.PerfumeDAOImpl;
import com.perfume.model.Notice;
import com.perfume.model.Perfume;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(PerfumeDAOImpl.class)
public class PerfumeDAOUnitTest {

    @Autowired
    private PerfumeDAO pdao;

    @Test
    @DisplayName("PerfumeDAO select Test")
    void selectPerfume() {
        int cpg=1;
        int stnum=(cpg-1)*10;
        List<Perfume> results=pdao.selectPerfume(stnum);
        assertNotNull(results);
    }

    @Test
    @DisplayName("PerfumeDAO category Test")
    void category() {
        String param = "샤넬";
        List<Perfume> results = pdao.category(param);
        assertNotNull(results);
    }
}
