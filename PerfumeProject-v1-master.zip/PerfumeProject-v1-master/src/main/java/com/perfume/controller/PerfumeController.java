package com.perfume.controller;

import com.perfume.model.*;
import com.perfume.service.PerfumeService;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/perfume")
@RequiredArgsConstructor
public class PerfumeController {

    @Autowired
    final PerfumeService psrv;

    Logger logger = LogManager.getLogger(IndexController.class);

    @GetMapping("/list/{cpg}")
    public String list(Model m, @PathVariable Integer cpg) {
        logger.info("perfume list 호출!");
        m.addAttribute("perfume", psrv.readPerfume(cpg));
        m.addAttribute("cpg", cpg);
        m.addAttribute("cntpg", psrv.countPage());
        m.addAttribute("stpg", ((cpg - 1) / 10) * 10 + 1);

        if (cpg > (int) m.getAttribute("cntpg")) {
            return "redirect:/perfume/list/1";
        }
        return "perfume/list";
    }
    @GetMapping("/view/{pno}")

    public String view(Model m, @PathVariable String pno, PComment pc, PQuestion pq) {
        logger.info("perfume view 호출!");
        m.addAttribute("p", psrv.readOnePerfume(pno));
        m.addAttribute("pcs", psrv.readComment(pc));
        m.addAttribute("qes", psrv.readQuestion(pq));

        return "perfume/view";
    }

    @GetMapping("/write")
    public String write() {
        logger.info("perfume write 호출!");
        return "perfume/write";
    }

    @PostMapping("/write")
    public String writeok(Perfume p, List<MultipartFile> attachs) throws IOException {
        logger.info("perfume write 호출!");
        String viewPage = "redirect:/perfume/write/fail";

        int pno=psrv.savePerfume(p);

        if (!attachs.isEmpty()) {
            psrv.savePerfumeAttach(attachs, pno);
            viewPage = "redirect:/perfume/list/1";

        }
        return viewPage;
    }

    @PostMapping("/cmt/write")
    public String cmtwrtok(PComment nc) {
        logger.info("perfume cmt wrt 호출!");
        String viewPage = "redirect:/perfume/fail";

        // 1 댓글을 먼저 DB에 저장
        if(psrv.newComment(nc)){
            // 작성한 댓글을 확인하기 위해 바로 본문 출력
            viewPage = "redirect:/view/" + nc.getCno();

        }
        return viewPage;
    }


    @PostMapping("/reply/write")
    public String rpywrtok(NComment nc) {
        logger.info("perfume rpy wrt 호출!");
        String viewPage = "redirect:/perfume/fail";
        return viewPage;
    }


    @GetMapping("/list/{param}/{cpg}")
    public String category(Model m, @PathVariable String param, @PathVariable Integer cpg){
        logger.info("perfume category 호출!");
        m.addAttribute("perfume", psrv.category(param));
        m.addAttribute("param", param);
        m.addAttribute("cpg", cpg);
        m.addAttribute("stpg", ((cpg - 1) / 10) * 10 + 1);

        return "perfume/list";
    }

    @PostMapping("/comment")
    public String comment(PComment pc) {
        logger.info("perfume comment 호출!");
        String viewPage="redirect:/perfume/comment/fail";
        if(psrv.newComment(pc)) {
            viewPage="redirect:/perfume/view/" + pc.getPno();
        }
        return viewPage;
    }

    @PostMapping("/question")
    public String question(PQuestion pq) {
        logger.info("perfume question 호출!");
        String viewPage="redirect:/perfume/question/fail";
        if(psrv.newQuestion(pq)) {
            viewPage="redirect:/perfume/view/" + pq.getPno();
        }
        return viewPage;
    }
}
