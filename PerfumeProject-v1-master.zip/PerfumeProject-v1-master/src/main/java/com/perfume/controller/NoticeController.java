package com.perfume.controller;

import com.perfume.model.Notice;
import com.perfume.service.NoticeService;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.util.Map;

@Controller
@RequestMapping("/notice")
@RequiredArgsConstructor
public class NoticeController {
    @Autowired
    final NoticeService nsrv;

    Logger logger = LogManager.getLogger(NoticeController.class);

    @GetMapping("/list/{cpg}")
    public String list(Model m, @PathVariable Integer cpg) {
        logger.info("notice list 호출!");
        m.addAttribute("notice", nsrv.readNotice(cpg));
        m.addAttribute("cpg", cpg);
        m.addAttribute("cntpg", nsrv.conutPage());
        m.addAttribute("stpg", ((cpg - 1) / 10) * 10 + 1);

        if (cpg > (int) m.getAttribute("cntpg")) {
            return "redirect:/notice/list/1";
        }
        return "notice/list";
    }

    @GetMapping("/view/{nno}")
    public String view(Model m, @PathVariable String nno) {
        logger.info("notice view 호출!");
        m.addAttribute("n", nsrv.readOneNotice(nno));
        return "notice/view";
    }

    @GetMapping("/write")
    public String write() {
        logger.info("notice write 호출!");
        return "notice/write";
    }

    @PostMapping("/write")
    public String writeok(Notice n, MultipartFile attach) {
        logger.info("notice write 호출!");
        String viewPage = "redirect:/notice/write/fail";

        int nno=nsrv.saveNotice(n);

        if (!attach.isEmpty()) {
            nsrv.saveNoticeAttach(attach, nno);
            viewPage = "redirect:/notice/list/1";
        }
        return viewPage;
    }

    @GetMapping("/down/{nno}")
    public ResponseEntity<Resource> down(Model m, @PathVariable String nno){
        logger.info("notice down 호출!");
        String nname=nsrv.readOneNoticeAttach(nno);
        Map<String, Object> obj = nsrv.getHeaderResource(nname);

        return ResponseEntity.ok()
                .headers((HttpHeaders) obj.get("header"))
                .body((UrlResource) obj.get("resource"));
    }
    @GetMapping("/delete/{nno}")
    public String remove(@PathVariable String nno) {
        logger.info("notice remove 호출!");
        String viewPage = "redirect:/notice/fail";
        if (nsrv.removeNotice(nno)) {
            viewPage = "redirect:/notice/list/1";
        }
        return viewPage;
    }

    @PostMapping("/modify/{nno}")
    public String modifyok(Notice n, @PathVariable String nno, @PathVariable MultipartFile attach) {
        logger.info("notice modify 호출!");
        String viewPage = "redirect:/notice/fail";
        if (nsrv.modifyNotice(n)) {
            nsrv.modifyNoticeAttach(attach, nno);
            viewPage = "redirect:/notice/list/1";
        }
        return viewPage;
    }

    @GetMapping("/modify/{nno}")
    public String modify(Model m, @PathVariable String nno) {
        logger.info("notice modify 호출!");
        m.addAttribute("notice", nsrv.readOneNotice(nno));
        return "notice/modify";
    }
    @GetMapping("/find/{findtype}/{findkey}/{cpg}")
    public String find(Model m, @PathVariable Integer cpg,
                       @PathVariable String findtype, @PathVariable String findkey) {
        logger.info("notice find 호출!");
        m.addAttribute("notice", nsrv.findNotice(cpg, findtype, findkey));
        m.addAttribute("cpg", cpg);
        m.addAttribute("cntpg", nsrv.conutPage());
        m.addAttribute("stpg", ((cpg - 1) / 10) * 10 + 1);
        m.addAttribute("findkey", findkey);

        if (cpg > (int) m.getAttribute("cntpg")) {
            return "redirect:/notice/list/1";
        }
        return "notice/list";
    }
}