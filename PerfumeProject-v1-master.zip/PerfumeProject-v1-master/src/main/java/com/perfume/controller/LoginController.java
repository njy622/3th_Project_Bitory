package com.perfume.controller;

import com.perfume.model.Member;
import com.perfume.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/member")
@RequiredArgsConstructor
public class LoginController {
    @Autowired
    MemberService msrv;

    Logger logger = LogManager.getLogger(IndexController.class);

    @GetMapping("/login")
    public String login() {
        logger.info("login 호출!");

        return "member/login";
    }

    @PostMapping("/login")
    public String loginok(Member m, HttpSession sess) {
        logger.info("loginok 호출!!");
        String returnPage = "redirect:/loginfail";

        m = msrv.readOneMember(m);
        if (m != null) {
            sess.setAttribute("member", m);
            returnPage = "redirect:/";
        }
        return returnPage;
    }

    @GetMapping("/logout")
    public String logout(HttpSession sess) {

        sess.invalidate();

        // logout하면 index 페이지로 넘어감
        return "redirect:/";
    }


    @GetMapping("/findId")
    public String find() {
        logger.info("findId 호출!");

        return "member/findId";
    }

    @GetMapping("/findPw")
    public String findPw() {
        logger.info("findPw 호출!");

        return "member/findPw";
    }

    @GetMapping("/mileage")
    public String mileage() {
        logger.info("mileage 호출!");

        return "member/mileage";
    }

    @GetMapping("/myboard")
    public String myboard() {
        logger.info("myboard 호출!");

        return "member/myboard";
    }

    // 회원정보 수정
    @GetMapping("/modify")
    public String modify() {
        logger.info("modfiy 호출!");


        return "member/modify";
    }
    @PostMapping("/modifyok")
    public String modifyok(Member m) {
        logger.info("modifyOk 호출!");
        logger.info(m.getZipcode());
        m.setZipcode(m.getZipcode().replace(",", ""));  // zipcode 뒤에 들어오는 콤마 삭제
         if (msrv.updateMember(m)) {
             return "member/mypage";
         }
        return "member/modify";
    }

    // 회원탈퇴
    @GetMapping("/delete")
    public String delete(Member m, HttpSession sess) {
        logger.info("delete 호출!");
        String returnPage = "redirect:/deletefail";
        System.out.print(m);
        if(msrv.deleteMember(m)) {
            returnPage = "redirect:/";
            sess.invalidate();
        }

        return returnPage;
    }


    }