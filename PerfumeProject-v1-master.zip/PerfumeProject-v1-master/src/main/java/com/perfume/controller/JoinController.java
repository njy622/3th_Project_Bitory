package com.perfume.controller;

import com.perfume.model.Member;
import com.perfume.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Controller
@RequestMapping("/member")
@RequiredArgsConstructor
public class JoinController {
    @Autowired
    MemberService msrv;

    Logger logger = LogManager.getLogger(NoticeController.class);
    @GetMapping("/join")
    public String list() {
        logger.info("join 호출!");

        return "member/join";
    }

    @PostMapping("/join")
    public String joinok(Member m) {
        logger.info("joinok 호출!");
        String returnpage = "redirect:/join/fail";
        logger.info(m.getZipcode());
        m.setZipcode(m.getZipcode().replace(",", ""));  // zipcode 뒤에 들어오는 콤마 삭제

        if(msrv.saveMember(m)){
            returnpage = "redirect:/member/login";
        }
        return returnpage;
    }

    @GetMapping("/mypage")
    public String mypage(Member m, HttpSession sess) {
        logger.info("mypage 호출!");

        return "member/mypage";
    }


    @GetMapping("/zipcode/{dong}")
    @ResponseBody
    public void findzip(@PathVariable String dong, HttpServletResponse res) throws IOException {
        res.setContentType("application/json; charset=utf-8");
        res.getWriter().print(msrv .findzip(dong));
    }

    @GetMapping("/checkuid/{uid}")     // 위의 두번째 방식으로 변수를 받아서 쓰기
    @ResponseBody
    // @PathVariable : url의 일부를 변수처럼 사용하고 싶다.
    public void checkuid(@PathVariable String uid, HttpServletResponse res) throws IOException {
        res.setContentType("application/json; charset=utf-8");

        res.getWriter().print(msrv.checkuid(uid));
    }

}
