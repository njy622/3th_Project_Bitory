package com.perfume.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndexController {
    Logger logger = LogManager.getLogger(IndexController.class);
    @GetMapping("/index")
    public String index(){
        logger.info("index 호출");
        return "index";
    }
    @GetMapping("/about")
    public String about(){
        logger.info("about 호출");
        return "cont/about";
    }

    @GetMapping("/agreement")
    public String agreement(){
        logger.info("agreement 호출");
        return "cont/agreement";
    }

    @GetMapping("/pp")
    public String pp(){
        logger.info("privacy policy  호출");
        return "cont/pp";
    }
    @GetMapping("/guide")
    public String guide(){
        logger.info("guide 호출");
        return "shopInfo/guide";
    }

}
