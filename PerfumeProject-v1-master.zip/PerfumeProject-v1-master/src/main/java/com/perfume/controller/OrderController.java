package com.perfume.controller;

import com.perfume.model.*;
import com.perfume.service.MemberService;
import com.perfume.service.OrderService;
import com.perfume.service.PerfumeService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/order")
public class OrderController {
    @Autowired
    private OrderService osrv;

    Logger logger = LogManager.getLogger(com.perfume.controller.OrderController.class);
    @GetMapping("/cart/{mno}")
    public String cart(Model m, @PathVariable Integer mno) {
        logger.info("cart 호출");
        System.out.println(mno);
        if (osrv.readCart_View(mno)!=null){
            m.addAttribute("cartview", osrv.readCart_View(mno));
            m.addAttribute("totalprod", osrv.readCart_ViewList(mno));
            m.addAttribute("totalprice", osrv.readCart_ViewSum(mno));
        }
        return "order/cart";
    }
    @PostMapping("/cart/enter/{mno}")
    public String cartenter(Model m, Cart cart, @PathVariable Integer mno){
        logger.info("cart 호출");

        osrv.saveCart(cart);
        if (osrv.readCart_View(mno)!=null){
            m.addAttribute("cartview", osrv.readCart_View(mno));
            m.addAttribute("totalprod", osrv.readCart_ViewList(mno));
            m.addAttribute("totalprice", osrv.readCart_ViewSum(mno));
        }

        return "order/cart";
    }
    @GetMapping("/myorder/{mno}")
    public String myoder(Model m, @PathVariable Integer mno){
        logger.info("myoder 호출");
        if (osrv.readOrder_View(mno)!=null) {
            m.addAttribute("view", osrv.readOrder_View(mno));
        }
        return "order/myorder";
    }
    @GetMapping("/cancel/{mno}")
public String cancel(@PathVariable Integer mno){
        logger.info("cancel 호출");
        return "order/cancel";
    }
    @PostMapping("/payment/{mno}")
    public String payment(Model m, @PathVariable Integer mno){
        logger.info("payment 호출");
        System.out.println(mno);
        m.addAttribute("productview",osrv.readCart_View(mno));
        m.addAttribute("totalprice",osrv.readCart_ViewSum(mno));
        m.addAttribute("discount",Math.round(osrv.readCart_ViewSum(mno)*0.10));
        return "order/payment";
    }
    @PostMapping("/payment/enter/{mno}")
    public String paymentok(Model m, Order_Detail detail, @PathVariable Integer mno){
        logger.info("paymentok 호출");
        System.out.println(mno);
        String viewpage = "redirect:/order/fail";
        System.out.println(detail);
        if (osrv.saveOrders(mno) && osrv.saveOrder_Detail(detail))
            viewpage = "redirect:/order/complete/" + mno;

        m.addAttribute("totalprice",osrv.readCart_ViewSum(mno));
        return viewpage;
    }


    @PostMapping("/complete/{mno}")
    public String complete(Model m, @PathVariable Integer mno, Order_Detail detail){
        logger.info("complete 호출");

        osrv.saveOrders(mno);
        osrv.saveOrder_Detail(detail);
        System.out.println(osrv.readOrder_View(mno));
        m.addAttribute("view", osrv.readOrder_View(mno));
        return "order/complete";
    }
}
