package com.perfume.service;

import com.perfume.dao.OrderDAO;
import com.perfume.model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import java.util.List;
@Service("osrv")
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService{
    final OrderDAO orderDAO;
    @Override
    public boolean saveOrders(Integer mno) {
        return (orderDAO.insertOrders(mno) > 0) ? true : false;
    }

    @Override
    public int readOrders(Integer mno) {
        return orderDAO.selectOrders(mno);
    }


    @Override
    public boolean saveOrder_Detail(Order_Detail detail) {
        return (orderDAO.insertOrder_Detail(detail)>0) ? true : false;
    }

    @Override
    public List<Order_View> readOrder_View(Integer mno) {
        return orderDAO.selectOrder_View(mno);
    }

    @Override
    public boolean saveCart(Cart c) {
        return (orderDAO.insertCart(c)>0) ? true : false;
    }

    @Override
    public List<Cart_View> readCart_View(Integer mno) {
        return orderDAO.selectCart_View(mno);
    }

    @Override
    public int readCart_ViewSum(Integer mno) {
        return orderDAO.selectCart_ViewSum(mno);
    }

    @Override
    public int readCart_ViewList(Integer mno) {
        return orderDAO.selectCart_ViewList(mno);
    }
}
