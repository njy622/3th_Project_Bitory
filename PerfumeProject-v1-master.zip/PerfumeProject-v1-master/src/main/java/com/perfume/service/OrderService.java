package com.perfume.service;

import com.perfume.model.*;

import java.util.List;

public interface OrderService {
    boolean saveOrders(Integer mno);
    int readOrders(Integer mno);
    boolean saveOrder_Detail(Order_Detail detail);
    List<Order_View> readOrder_View(Integer mno);
    boolean saveCart(Cart c);
    List<Cart_View> readCart_View(Integer mno);
    int readCart_ViewSum(Integer mno);
    int readCart_ViewList(Integer mno);
}
