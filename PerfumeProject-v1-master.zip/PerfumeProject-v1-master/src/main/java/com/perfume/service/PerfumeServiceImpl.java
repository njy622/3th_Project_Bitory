package com.perfume.service;


import com.perfume.dao.PerfumeDAO;
import com.perfume.model.*;
import com.perfume.utils.Perutils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service("psrv")
@RequiredArgsConstructor
public class PerfumeServiceImpl implements PerfumeService {

    final PerfumeDAO pdao;
    final Perutils perutils;

    @Override
    public int countPage() {
        return pdao.countPage();
    }

    @Override
    public List<Perfume> readPerfume(Integer cpg) {
        int stnum=(cpg-1) * 10;
        return pdao.selectPerfume(stnum);
    }

    @Override
    public int savePerfume(Perfume p) {
        return pdao.insertPerfume(p);
    }

    @Override
    public boolean savePerfumeAttach(List<MultipartFile> attachs, int pno) throws IOException {
        PerfumeAttach pa = perutils.processUpload(attachs);

        pa.setPno(pno + "");

        int pacnt=pdao.insertPerfumeAttach(pa);
        return (pacnt > 0) ? true : false;
    }

    @Override
    public Perfume readOnePerfume(String pno) {
        return pdao.selecOnePerfume(pno);
    }

    @Override
    public List<Perfume> category(String param) {
        return pdao.category(param);
    }

    @Override
    public boolean newComment(PComment pc) {
        int comment=pdao.insertComment(pc);
        return (comment > 0) ? true : false;
    }

    @Override
    public List<PComment> readComment(PComment pc) {
        return pdao.selectComment(pc);
    }

    @Override
    public boolean newQuestion(PQuestion pq) {
        int question=pdao.insertQuestion(pq);
        return (question > 0) ? true : false;
    }

    @Override
    public List<PQuestion> readQuestion(PQuestion pq) {
        return pdao.selectQuestion(pq);
    }


}
