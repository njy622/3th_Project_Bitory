package com.perfume.service;

import com.perfume.dao.NoticeDAO;
import com.perfume.model.Notice;
import com.perfume.model.NoticeAttach;
import com.perfume.utils.NotUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("nsrv")
@RequiredArgsConstructor
public class NoticeServiceImpl implements NoticeService {
    @Autowired
    final NoticeDAO ndao;
    final NotUtils notUtils;
    @Override
    public List<Notice> readNotice(Integer cpg) {
        int stnum=(cpg-1)*10;
        return ndao.selectNotice(stnum);
    }

    @Override
    public int conutPage() {
        return ndao.countPage();
    }

    @Override
    public int saveNotice(Notice n) {
        return ndao.insertNotice(n);
    }


    @Override
    public Notice readOneNotice(String nno) {
        return ndao.selectOneNotice(nno);
    }

    @Override
    public boolean saveNoticeAttach(MultipartFile attach, int nno) {
        NoticeAttach na=notUtils.processUpload(attach);
        na.setNno(nno + "");
        int nacnt=ndao.insertNoticeAttach(na);
        return (nacnt > 0) ? true : false;
    }
    @Override
    public String readOneNoticeAttach(String nno) {
        NoticeAttach na = ndao.selectOneNoticeAttach(nno);
        return na.getNname();
    }
    @Override
    public Map<String, Object> getHeaderResource(String nname) {
        Map<String, Object> objs=new HashMap<>();
        objs.put("header", notUtils.getHeader(nname));
        objs.put("resource", notUtils.getResource(nname));
        return objs;
    }
    @Override
    public List<Notice> findNotice(Integer cpg, String findtype, String findkey) {
        Map<String, Object> params=new HashMap<>();
        params.put("findtype", findtype);
        params.put("findkey", findkey);
        params.put("stnum", (cpg-1) * 10);
        return ndao.findNotice(params);
    }
    @Override
    public boolean removeNotice(String nno) {
        boolean isRemoved=false;
        if(ndao.deleteNotice(nno) > 0) isRemoved=true;
        return isRemoved;
    }
    @Override
    public boolean modifyNotice(Notice n) {
        boolean isModified=false;
        if(ndao.modifyNotice(n) > 0) isModified=true;
        return isModified;
    }

    @Override
    public boolean modifyNoticeAttach(MultipartFile attach, String nno) {
        NoticeAttach na=notUtils.processUpload(attach);
        na.setNno(nno + "");
        int nacnt=ndao.insertNoticeAttach(na);
        return (nacnt > 0) ? true : false;
    }
}
