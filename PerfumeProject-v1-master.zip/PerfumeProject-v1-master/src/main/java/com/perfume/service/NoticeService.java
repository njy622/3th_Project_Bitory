package com.perfume.service;

import com.perfume.model.Notice;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface NoticeService {
    List<Notice> readNotice(Integer cpg);
    int conutPage();

    int saveNotice(Notice n);

    boolean removeNotice(String nno);

    Notice readOneNotice(String nno);

    boolean saveNoticeAttach(MultipartFile attach, int nno);

    String readOneNoticeAttach(String nno);

    Map<String, Object> getHeaderResource(String nname);

    List<Notice> findNotice(Integer cpg, String findtype, String findkey);

    boolean modifyNotice(Notice n);

    boolean modifyNoticeAttach(MultipartFile attach, String nno);
}
