package com.perfume.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfume.dao.MemberDAO;
import com.perfume.model.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service("msrv")
public class MemberServiceImpl implements MemberService {

    @Autowired
    private MemberDAO mdao;

    @Override
    public boolean saveMember(Member m) {
        boolean isSaved = false;

        if(mdao.insertMember(m)>0) isSaved = true;

        return isSaved;
    }

    @Override
    public List<Member> readMember() {
        return mdao.selectMember();
    }

    @Override
    public String findzip(String dong) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        String json = "";
        dong = dong +'%';

        json = mapper.writeValueAsString(mdao.selectzip(dong));

        return json;
    }

    @Override
    public int checkuid(String uid) {
        return mdao.selectOneUserid(uid);
    }

    @Override
    public Member readOneMember(Member m) {
        return mdao.selectOneMember(m);
    }

    @Override
    public boolean deleteMember(Member m) {
        return (mdao.deleteMember(m)>0)? true : false ;
    }

    @Override
    public boolean updateMember(Member m) {
        return mdao.updateMember(m);
    }


}
