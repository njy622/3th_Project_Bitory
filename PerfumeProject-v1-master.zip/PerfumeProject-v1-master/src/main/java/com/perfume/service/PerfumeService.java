package com.perfume.service;

import com.perfume.model.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface PerfumeService {

    int countPage();

    List<Perfume> readPerfume(Integer cpg);

    int savePerfume(Perfume p);

    boolean savePerfumeAttach(List<MultipartFile> attachs, int pno) throws IOException;
    Perfume readOnePerfume(String pno);

    List<Perfume> category(String param);

    boolean newComment(PComment pc);

    List<PComment> readComment(PComment pc);

    boolean newQuestion(PQuestion pq);

    List<PQuestion> readQuestion(PQuestion pq);

}
