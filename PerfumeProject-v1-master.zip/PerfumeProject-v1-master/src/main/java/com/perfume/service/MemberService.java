package com.perfume.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.perfume.model.Member;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


public interface MemberService {
    boolean saveMember(Member m);

    List<Member> readMember();

    String findzip(String dong) throws JsonProcessingException;

    int checkuid(String uid);

    Member readOneMember(Member m);

    boolean deleteMember(Member m);

    boolean updateMember(Member m);
}
