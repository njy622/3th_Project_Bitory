package com.perfume.model;

import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class Member {
    private String mno;
    private String username;
    private String userid;
    private String passwd;
    private String phone;
    private String email;
    private String zipcode;
    private String addr1;
    private String addr2;
    private String regdate;

}
