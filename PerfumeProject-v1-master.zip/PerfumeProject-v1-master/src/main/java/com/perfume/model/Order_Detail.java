package com.perfume.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
public class Order_Detail {
    private String odno;
    private String orderno;
    private String pfno;
    private String quantity;
    private String result;
}
