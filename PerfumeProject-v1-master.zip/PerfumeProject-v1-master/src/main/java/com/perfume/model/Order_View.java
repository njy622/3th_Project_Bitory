package com.perfume.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
public class Order_View {
    private String odno;
    private String ono;
    private String userid;
    private String regdate;
    private String pfno;
    private String quantity;
    private String username;
    private String zipcode;
    private String addr1;
    private String addr2;
    private String phone;
    private String name;
    private String price;
    private String pname;
    private String result;
}
