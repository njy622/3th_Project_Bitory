package com.perfume.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PerfumeAttach {
    private String pano;
    private String pno;
    private String pname;
    private String psize;
}
