package com.perfume.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Notice {
    private String nno;
    private String title;
    private String contents;
    private String userid;
    private String views;
    private String thumbs;
    private String regdate;

    private NoticeAttach noticeAttach;

}
