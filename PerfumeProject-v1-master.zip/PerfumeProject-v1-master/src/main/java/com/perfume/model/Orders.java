package com.perfume.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public class Orders {
    private String ono;
    private String mno;
    private String regdate;
}
