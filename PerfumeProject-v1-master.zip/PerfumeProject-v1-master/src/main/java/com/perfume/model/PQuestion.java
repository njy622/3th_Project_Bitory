package com.perfume.model;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PQuestion {
    private String pno;
    private String qno;
    private String userid;
    private String question;
    private String regdate;
}
