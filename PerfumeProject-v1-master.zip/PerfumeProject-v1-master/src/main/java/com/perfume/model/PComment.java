package com.perfume.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PComment {
    private String pno;
    private String cno;
    private String userid;
    private String comment;
    private String regdate;

}
