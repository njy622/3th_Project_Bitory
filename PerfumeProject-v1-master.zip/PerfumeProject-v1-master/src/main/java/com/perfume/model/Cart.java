package com.perfume.model;

import lombok.*;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Cart {
    private String cno;
    private String mno;
    private String pno;
    private String quantity;
    private String regdate;
}
