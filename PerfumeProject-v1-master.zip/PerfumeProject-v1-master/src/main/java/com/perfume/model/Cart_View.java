package com.perfume.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
public class Cart_View {
    private String cno;
    private String mno;
    private String pno;
    private String mname;
    private String pname;
    private String quantity;
    private String regdate;
    private String price;
    private String paname;
}
