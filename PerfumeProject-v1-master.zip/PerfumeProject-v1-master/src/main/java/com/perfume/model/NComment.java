package com.perfume.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class NComment {
    private String cno;
    private String comment;
    private String userid;
    private String regdate;
    private String nno;
    private String ref;
}
