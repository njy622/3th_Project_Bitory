package com.perfume.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class NoticeAttach {
    private String nano;
    private String nno;
    private String nname;
    private String ntype;
    private String nsize;
    private String ndown;

}
