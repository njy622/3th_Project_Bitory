package com.perfume.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Perfume {
    private String pno;
    private String name;
    private String brand;
    private String volume;
    private String price;
    private String image;
    private String count;


    private PerfumeAttach pa;
}
