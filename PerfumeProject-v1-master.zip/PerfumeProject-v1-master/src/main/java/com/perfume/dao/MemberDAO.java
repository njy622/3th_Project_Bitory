package com.perfume.dao;

import com.perfume.model.Member;
import com.perfume.model.Zipcode;

import java.util.List;

public interface MemberDAO {
    int insertMember(Member m);

    List<Member> selectMember();

    int selectOneUserid(String uid);

    Member selectOneMember(Member m);

    List<Zipcode> selectzip(String dong);

    int deleteMember(Member m);

    boolean updateMember(Member m);
}
