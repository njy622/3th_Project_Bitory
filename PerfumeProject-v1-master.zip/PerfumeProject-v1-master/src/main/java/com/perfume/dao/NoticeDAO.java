package com.perfume.dao;

import com.perfume.model.Notice;
import com.perfume.model.NoticeAttach;

import java.util.List;
import java.util.Map;

public interface NoticeDAO {
    List<Notice> selectNotice(int stnum);
    int countPage();

    int insertNotice(Notice n);

    int deleteNotice(String nno);

    Notice selectOneNotice(String nno);

    int insertNoticeAttach(NoticeAttach na);

    NoticeAttach selectOneNoticeAttach(String nno);

    List<Notice> findNotice(Map<String, Object> params);

    int modifyNotice(Notice n);

    int modifyNoticeAttach(String nno);
}
