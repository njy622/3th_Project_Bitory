package com.perfume.dao;

import com.perfume.model.*;

import java.util.List;

public interface PerfumeDAO {

    int countPage();

    List<Perfume> selectPerfume(int stnum);

    int insertPerfume(Perfume p);

    int insertPerfumeAttach(PerfumeAttach pa);

    Perfume selecOnePerfume(String pno);

    List<Perfume> category(String param);

    int insertComment(PComment pc);

    List<PComment> selectComment(PComment pc);

    int insertQuestion(PQuestion pq);

    List<PQuestion> selectQuestion(PQuestion pq);

}
