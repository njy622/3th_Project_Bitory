package com.perfume.dao;

import com.perfume.model.Member;
import com.perfume.model.Zipcode;
import com.perfume.mybatis.MemberMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository("mdao")
@RequiredArgsConstructor

public class MemberDAOImpl implements MemberDAO {

    @Autowired
    private MemberMapper memberMapper;

    @Override
    public int insertMember(Member m) {

        return memberMapper.insertMember(m);
    }

    @Override
    public List<Member> selectMember() {
        return memberMapper.selectMember();
    }

    @Override
    public int selectOneUserid(String uid) {
        return memberMapper.selectOneUserid(uid);
    }

    @Override
    public Member selectOneMember(Member m) {
        return memberMapper.selectOneMember(m);
    }

    @Override
    public List<Zipcode> selectzip(String dong) {
        return memberMapper.findZipcode(dong);
    }

    @Override
    public int deleteMember(Member m) {
        return memberMapper.deleteMember(m);
    }

    @Override
    public boolean updateMember(Member m) {
        return memberMapper.updateMember(m);
    }


}
