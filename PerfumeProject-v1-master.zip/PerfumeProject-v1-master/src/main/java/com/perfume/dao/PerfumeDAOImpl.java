package com.perfume.dao;

import com.perfume.model.*;
import com.perfume.mybatis.PerfumeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("pdao")
public class PerfumeDAOImpl implements PerfumeDAO {

    @Autowired
    private PerfumeMapper perfumeMapper;

    @Override
    public int countPage() {
        return perfumeMapper.countPage();
    }

    @Override
    public List<Perfume> selectPerfume(int stnum) {
        return perfumeMapper.selectPerfume(stnum);
    }

    @Override
    public int insertPerfume(Perfume p) {
        int cnt=perfumeMapper.insertPerfume(p);
        if(cnt > 0) {
            cnt=perfumeMapper.lastPerPno();
        }
        return cnt;
    }

    @Override
    public int insertPerfumeAttach(PerfumeAttach pa) {
        return perfumeMapper.insertPerfumeAttach(pa);
    }

    @Override
    public Perfume selecOnePerfume(String pno) {
        return perfumeMapper.selectOnePerfume(pno);
    }

    @Override
    public List<Perfume> category(String param) {
        return perfumeMapper.category(param);
    }

    @Override
    public int insertComment(PComment pc) {
        return perfumeMapper.insertComment(pc);
    }

    @Override
    public List<PComment> selectComment(PComment pc) {
        return perfumeMapper.selectComment(pc);
    }

    @Override
    public int insertQuestion(PQuestion pq) {
        return perfumeMapper.insertQuestion(pq);
    }

    @Override
    public List<PQuestion> selectQuestion(PQuestion pq) {
        return perfumeMapper.selectQuestion(pq);
    }

}
