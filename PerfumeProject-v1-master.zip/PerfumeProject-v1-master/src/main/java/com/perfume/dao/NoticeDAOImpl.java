package com.perfume.dao;

import com.perfume.model.Notice;
import com.perfume.model.NoticeAttach;
import com.perfume.mybatis.NoticeMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@Repository
@RequiredArgsConstructor
public class NoticeDAOImpl implements NoticeDAO {
    @Autowired
    final NoticeMapper noticeMapper;

    @Override
    public List<Notice> selectNotice(int stnum) {
        return noticeMapper.selectNotice(stnum);
    }

    @Override
    public int countPage() {
        return noticeMapper.countPage();
    }

    @Override
    public int insertNotice(Notice n) {
        int cnt=noticeMapper.insertNotice(n);
        if(cnt > 0) {
            cnt=noticeMapper.lastNoticeNno();
        }
        return cnt;
    }

    @Override
    public int deleteNotice(String nno) {
        return noticeMapper.deleteNotice(nno);
    }

    @Override
    public Notice selectOneNotice(String nno) {
        noticeMapper.viewsUp(nno);
        return noticeMapper.selectOneNotice(nno);
    }

    @Override
    public int insertNoticeAttach(NoticeAttach na) {
        return noticeMapper.insertNoticeAttach(na);
    }

    @Override
    public NoticeAttach selectOneNoticeAttach(String nno) {
        return noticeMapper.selectOneNoticeAttach(nno);
    }

    @Override
    public List<Notice> findNotice(Map<String, Object> params) {
        return noticeMapper.findNotice(params);
    }

    @Override
    public int modifyNotice(Notice n) {
        return noticeMapper.modifyNotice(n);
    }

    @Override
    public int modifyNoticeAttach(String nno) {
        return noticeMapper.modifyNoticeAttach(nno);
    }
}
