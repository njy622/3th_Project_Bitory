package com.perfume.dao;

import com.perfume.model.*;

import java.util.List;

public interface OrderDAO {
    int insertOrders(Integer mno);
    int selectOrders(Integer mno);
    int insertOrder_Detail(Order_Detail detail);
    List<Order_View> selectOrder_View(Integer mno);
    int insertCart(Cart c);
    List<Cart_View> selectCart_View(Integer mno);
    int selectCart_ViewSum(Integer mno);
    int selectCart_ViewList(Integer mno);
}
