package com.perfume.dao;

import com.perfume.model.*;
import com.perfume.mybatis.OrderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository("odao")
@RequiredArgsConstructor
public class OrderDAOImpl implements OrderDAO{
    final OrderMapper orderMapper;

    @Override
    public int insertOrders(Integer mno) {
        return orderMapper.insertOrders(mno);
    }

    @Override
    public int selectOrders(Integer mno) {
        return orderMapper.selectOrders(mno);
    }

    @Override
    public int insertOrder_Detail(Order_Detail detail) {
        return orderMapper.insertOrder_Detail(detail);
    }

    @Override
    public List<Order_View> selectOrder_View(Integer mno) {
        return orderMapper.selectOrder_View(mno);
    }

    @Override
    public int insertCart(Cart c) {
        return orderMapper.insertCart(c);
    }

    @Override
    public List<Cart_View> selectCart_View(Integer mno) {
        return orderMapper.selectCart_View(mno);
    }

    @Override
    public int selectCart_ViewSum(Integer mno) {
        return orderMapper.selectCart_ViewSum(mno);
    }

    @Override
    public int selectCart_ViewList(Integer mno) {
        return orderMapper.selectCart_ViewList(mno);
    }
}
