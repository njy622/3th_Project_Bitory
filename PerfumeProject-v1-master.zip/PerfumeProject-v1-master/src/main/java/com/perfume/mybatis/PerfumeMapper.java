package com.perfume.mybatis;

import com.perfume.model.*;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface PerfumeMapper {
    int countPage();

    List<Perfume> selectPerfume(int stnum);

    Perfume selectOnePerfume(String pno);

    int insertPerfume(Perfume p);

    int lastPerPno();

    int insertPerfumeAttach(PerfumeAttach pa);

    List<Perfume> category(String param);

    int insertComment(PComment pc);

    List<PComment> selectComment(PComment pc);

    int insertQuestion(PQuestion pq);

    List<PQuestion> selectQuestion(PQuestion pq);

}
