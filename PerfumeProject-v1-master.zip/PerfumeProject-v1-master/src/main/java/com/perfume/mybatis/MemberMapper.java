package com.perfume.mybatis;

import com.perfume.model.Member;
import com.perfume.model.Zipcode;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MemberMapper {
    int insertMember(Member m);
    List<Member> selectMember();

    List<Zipcode> findZipcode(String dong);

    int selectOneUserid(String uid);

    Member selectOneMember(Member m);

    int deleteMember(Member m);

    boolean updateMember(Member m);
}
