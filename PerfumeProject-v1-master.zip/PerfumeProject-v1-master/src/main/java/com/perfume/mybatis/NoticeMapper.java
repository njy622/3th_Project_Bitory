package com.perfume.mybatis;

import com.perfume.model.Notice;
import com.perfume.model.NoticeAttach;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@Mapper
public interface NoticeMapper {
    List<Notice> selectNotice(int stnum);

    int countPage();

    int viewsUp(String nno);

    int insertNotice(Notice n);

    int deleteNotice(String nno);

    Notice selectOneNotice(String nno);

    int lastNoticeNno();

    int insertNoticeAttach(NoticeAttach na);

    NoticeAttach selectOneNoticeAttach(String nno);

    List<Notice> findNotice(Map<String, Object> params);

    int modifyNotice(Notice n);

    int modifyNoticeAttach(String nno);
}
