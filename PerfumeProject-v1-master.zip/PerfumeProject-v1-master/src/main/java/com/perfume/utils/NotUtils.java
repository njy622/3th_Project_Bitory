package com.perfume.utils;

import com.perfume.model.NoticeAttach;
import com.perfume.model.PerfumeAttach;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriUtils;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Component
public class NotUtils {

    Logger logger= LogManager.getLogger(NotUtils.class);

    @Value("${saveNotDir}") private String saveNotDir;


    public NoticeAttach processUpload(MultipartFile attach) {
        NoticeAttach na=new NoticeAttach();

        na.setNname(makeUUId() + attach.getOriginalFilename());

        int nos=na.getNname().lastIndexOf(".") + 1;
        na.setNtype(na.getNname().substring(nos));
        na.setNsize(attach.getSize() / 1024 + "");

        String savepath=saveNotDir + na.getNname();
        try {
            attach.transferTo(new File(savepath));
        } catch (IOException e) {
            logger.error("첨부 파일을 처리하는 중 오류 발생!");
            e.printStackTrace();
        }
        return na;
    }

    private String makeUUId() {
        String uuid= LocalDate.now() + "" + LocalTime.now();
        uuid=uuid.replace("-", "")
                .replace(":", "")
                .replace(".", "");
        return uuid;
    }

    public Object getHeader(String nname) {
        HttpHeaders header=new HttpHeaders();
        nname= UriUtils.encode(nname, StandardCharsets.UTF_8);
        try {
            header.add("Content-Type", Files.probeContentType(Paths.get(saveNotDir + nname)));
            header.add("Content-Disposition", "attachment; filename=" + nname);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return header;
    }

    public Object getResource(String nname) {
        UrlResource resource=null;
        nname = UriUtils.encode(nname, StandardCharsets.UTF_8);
        try {
            resource = new UrlResource("file:" + saveNotDir + nname);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return resource;
    }
}
