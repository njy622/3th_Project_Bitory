package com.perfume.utils;

import com.perfume.model.PerfumeAttach;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Component
public class Perutils {

    Logger logger= LogManager.getLogger(Perutils.class);

    @Value("${saveDir}") private String saveDir;


    public PerfumeAttach processUpload(List<MultipartFile> attachs) throws IOException {
        PerfumeAttach pa=new PerfumeAttach();
        List<String> pnames=new ArrayList<>();
        List<String> psizes=new ArrayList<>();

        for (MultipartFile attach : attachs) {
            String pname=makeUUId() + attach.getOriginalFilename();
            String psize=attach.getSize() / 1024 + "";

            String savepath = saveDir + pname;
            try {
                attach.transferTo(new File(savepath));
                pnames.add(pname);
                psizes.add(psize);
            } catch (IOException e) {
                logger.error("첨부 파일을 처리하는 중 오류 발생!");
                e.printStackTrace();
            }
        }
        pa.setPname(String.join(";", pnames));
        pa.setPsize(String.join(";", psizes));
        return pa;
    }

    private String makeUUId() {
        String uuid= LocalDate.now() + "" + LocalTime.now();
        uuid=uuid.replace("-", "")
                .replace(":", "")
                .replace(".", "");
        return uuid;
    }
}
