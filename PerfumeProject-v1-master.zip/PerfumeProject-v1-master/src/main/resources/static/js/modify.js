let fzipbtn = document.querySelector("#findzipbtn");
let zipbtn = document.querySelector("#zipbtn");
let dong = document.querySelector("#dong");

let zipmodal = document.querySelector("#zipmodal");
let addrlist = document.querySelector("#addrlist");
let sendzip = document.querySelector("#sendzip");
let modal = null;   // 우편번호 모달

//우편번호 검색 모달창 띄우기
zipbtn?.addEventListener('click',()=> {
    while(addrlist.lastChild){
        addrlist.removeChild(addrlist.lastChild);
    }   //이전 검색 결과 지움
    dong.value = '';    //이전 검색 키워드 지움
    try{
        //새로운 모달 창 생성
        modal = new bootstrap.Modal(zipmodal, {});
    }catch (e){}
    modal.show();     // 모달창 띄우기
});
//검색한 우편번호 결과 출력
const showzipaddr = (jsons) => {
    jsons = JSON.parse(jsons); // 문자열을 json객체로 변환
    let addr = '';
    jsons.forEach(function (data, idx){
        // 주소 번지가 null일 경우 공백처리
        let bunji = data['bunji'] !== null ? data['bunji'] :'';
        addr += `<option>${data['zipcode']} ${data['sido']} 
                ${data['gugun']} ${data['dong']} ${bunji}</option>`;
    });
    addrlist.innerHTML = addr;
};
//우편번호 검색
fzipbtn?.addEventListener('click',()=> {
    if(dong.value === '') {
        alert('동이름을 입력하세요!!');
        return;
    }
    const url = '/member/zipcode/' + dong.value;
    fetch(url).then(response => response.text())
        .then(text => showzipaddr(text));
});
//주소 선택하고 닫기
sendzip?.addEventListener('click', () =>{
    let frm = document.forms.delfrm;
    let addr = addrlist.value;      // 선택한 주소 항목
    if (addr !== '') {
        let zip = addr.split(' ')[0];      // 우편번호 추출
        let addrs = addr.split(' ');
        let addr4 = `${addrs[4]}`;
        if (addr4==='undefined'){
            addr4 = '';
        }
        let vaddr =
            `${addrs[1]} ${addrs[2]} ${addrs[3]} ${addr[4]}`;   // 주소추출

        frm.zip.value = zip;     //[0] -> 첫번째꺼 추출
        frm.addr1.value = vaddr;
        console.log(zip);

        modal.hide();

    } else {
        alert('주소를 선택하세요!!');
    }
});

// 우편번호 검색 엔터키 입력차단
dong?.addEventListener('keydown',(e)=>{
    if(e.keyCode===13)
        e.preventDefault(); // 엔터키 입력되면 이벤트 전파 방지

});

// join - 비밀번호 확인
let pwd = document.querySelector('#pwd');
let repwd = document.querySelector('#repasswd');
let pwdmsg = document.querySelector('#pwdmsg');

// 비밀번호 입력규칙 :  영문 대소문자/숫자/특수문자 중 2가지 이상 조합, 10~16자
// 대문자, 소문자, 숫자, 특수문자를 검사하는 정규 표현식
let upper = /[A-Z]/;
let lower = /[a-z]/;
let number = /[0-9]/;
let special = /[!@#$%^&*]/;
repwd?.addEventListener('blur',() => {
    let pmsg = '비밀번호가 서로 일치하지 않습니다.';
    pwdmsg.className = 'text-danger';

    if (pwd.value === '' || repwd.value === '') {
        pmsg = '(영문 대소문자/숫자/특수문자 중 2가지 이상 조합, 10~16자)';
        pwdmsg.className = 'text-danger';
    } else {
        // 조합 개수 검증
        let matches = [upper.test(pwd.value), lower.test(pwd.value),
            number.test(pwd.value), special.test(pwd.value)].filter(Boolean).length;

        if(pwd.value.length < 10 || pwd.value.length > 16 || matches < 2) {
            pmsg = '(영문 대소문자/숫자/특수문자 중 2가지 이상 조합, 10~16자)';
            pwdmsg.className = 'text-danger';
        } else if (pwd.value === repwd.value) {
            pmsg = '비밀번호가 서로 일치합니다.';
            pwdmsg.className = 'text-primary';
        }
    }
    pwdmsg.innerText = pmsg;
});

// modify - 회원정보 수정 (아이디 제외하고)
let modbtn = document.querySelector("#modbtn");
let modpwd = document.querySelector("#pwd");
let modrepwd = document.querySelector("#repasswd");
let modaddr1 = document.querySelector("#addr1");
let modaddr2 = document.querySelector("#addr2");
let modphone1 = document.querySelector("#phone1");
let modphone2 = document.querySelector("#phone2");
let modphone3 = document.querySelector("#phone3");
let modemail1 = document.querySelector("#email1");
let modemail2 = document.querySelector("#email2");


modbtn?.addEventListener('click', () => {

    if(modpwd.value === '') alert('비밀번호를 입력하세요.');
    else if(modpwd.value === '') alert ('비밀번호를 입력하세요.')
    else if(modpwd.value !== modrepwd.value) alert('비밀번호를 확인하세요.');
    else if(modphone2.value==='' || modphone3.value === '') alert('전화번호를 입력하세요.');
    else if(modaddr1.value==='' || modaddr2.value === '') alert('주소를 입력하세요.');
    else if(modaddr1.value==='' || modaddr2.value === '') alert('상세주소를 입력하세요.');
    else if(modemail1.value==='' || modemail2.value === '') alert('이메일을 입력하세요.');
    else if(modphone2.value==='' || modphone3.value === '') alert('전화번호를 입력하세요.');
    else {
        delfrm.method = 'post';
        delfrm.action = '/member/modifyok';
        alert('회원정보 수정이 완료되었습니다!')
        delfrm.email.value = modemail1.value + '@' + modemail2.value;
        delfrm.phone.value = modphone1.value + '-' + modphone2.value + '-' + modphone3.value;
        delfrm.submit();
    }

});
// 필요한 DOM 요소 선택
let sendzipBtn = document.querySelector("#sendzip");
let addrList1 = document.querySelector("#addrlist");
/*
let zip = document.querySelector("#zip");
*/

sendzipBtn?.addEventListener('click', () => {
    // 사용자가 선택한 주소 가져오기
    let selectedAddr = addrList1.options[addrList1.selectedIndex].text;

    // 주소 필드에 선택한 주소 입력
    modaddr1.value = selectedAddr;


    // 모달 창 닫기
    $('#zipmodal').modal('hide');
});