let ntcbtn=document.querySelector("#ntcbtn");
ntcbtn?.addEventListener('click', ()=>{
        location.href = "/notice/write";
});

let wrtbtn=document.querySelector(".wrtbtn");
let wrtfrm=document.querySelector("#wrtfrm");
wrtbtn?.addEventListener('click', ()=>{
    if(wrtfrm.title.value==="") {
        alert("제목을 입력해주세요.")
    } else if (wrtfrm.contents.value==="") {
        alert("본문을 입력해주세요.")
    } else {
        wrtfrm.method='post';
        wrtfrm.enctype='multipart/form-data';
        wrtfrm.submit();
        alert("작성이 완료되었습니다.")
    }
});

let lstbdbtn=document.querySelector("#lstbdbtn")
lstbdbtn?.addEventListener('click', ()=> {
    location.href="/notice/list/1"
});

// 찾기
let findbtn=document.querySelector("#findbtn");
let findtype=document.querySelector("#findtype");
let findkey=document.querySelector("#findkey");

findbtn?.addEventListener('click', ()=>{
    location.href=`/notice/find/${findtype.value}/${findkey.value}/1`;
});


let rmvnotbtn=document.querySelector("#rmvnotbtn")
let remove=document.querySelector("#remove");
rmvnotbtn?.addEventListener('click', ()=>{
    if (confirm("글을 삭제하시겠습니까?")) {
        location.href = "/notice/delete/" + remove.value
    }
});


let modnotbtn=document.querySelector("#modnotbtn");
let modify=document.querySelector("#modify");
let userid=document.querySelector("#userid");
modnotbtn?.addEventListener('click', ()=> {
    if(userid.value == null) {
        alert("로그인 후 이용해주세요.")
    } else if (userid.value != null) {
        location.href="/notice/modify/" + modify.value
    } else {
        alert("알 수 없는 오류가 발생했습니다.");
    }
});

let modbtn=document.querySelector(".modbtn");
modbtn?.addEventListener('click', ()=>{
    let frm=document.forms.modfrm;
        frm.method = 'post';
        frm.enctype = 'multipart/form-data';
        frm.submit();
        alert("글이 수정되었습니다.");
});