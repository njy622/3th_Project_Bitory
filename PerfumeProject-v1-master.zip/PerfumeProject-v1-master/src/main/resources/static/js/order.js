//제품페이지에서 payment페이지로
let paybtn = document.querySelector("#paybtn");
paybtn?.addEventListener('click',()=>{
    location.href = '/order/payment';
});

//payment
let memberfrm = document.forms.memberfrm;
let oldaddr = document.querySelector("#oldaddr");
let newaddr = document.querySelector("#newaddr");
let payzip = document.querySelector("#payzip");
let payaddr1 = document.querySelector("#payaddr1");
let payaddr2 = document.querySelector("#payaddr2");

//배송지 선택
oldaddr?.addEventListener('focus',()=>{
    let frm = document.forms.payfrm;
    frm.payzip.value = memberfrm.memberzip.value;
    frm.payaddr1.value = memberfrm.memberaddr1.value;
    frm.payaddr2.value = memberfrm.memberaddr2.value;
});
newaddr?.addEventListener('focus',()=>{
    let frm = document.forms.payfrm;
    payzip.value = '';
    payaddr1.value = '';
    payaddr2.value = '';
});

let paybtn2 = document.querySelector("#paybtn2");
let cancelbtn = document.querySelector("#cancelbtn");
let mno = document.querySelector("#mno");
cancelbtn?.addEventListener('click',()=>{
    location.href = '/perfume/list/1';
});
paybtn2?.addEventListener('click',()=>{
    let frm = document.forms.payfrm;
    frm.method = 'post';
    frm.action = '/order/complete/' + mno.value;
    frm.submit();
});

//장바구니 페이지
let homebtn = document.querySelector("#homebtn");
let paymentbtn = document.querySelector("#paymentbtn");

homebtn?.addEventListener('click',()=>{
   location.href = '/index';
});
paymentbtn?.addEventListener('click',()=>{
    let frm = document.forms.cartfrm;

    frm.method = 'post';
    frm.action = '/order/payment/'+frm.mno.value;
    frm.submit();
});

let comphome = document.querySelector("#comphome");
let compshop = document.querySelector("#compshop");

compshop?.addEventListener('click',()=>{
    location.href = '/perfume/list/1';
});
comphome?.addEventListener('click',()=>{
    location.href = '/index';
});
