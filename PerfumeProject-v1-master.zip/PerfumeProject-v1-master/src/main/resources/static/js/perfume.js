let perwrt=document.querySelector("#perwrt");
perwrt?.addEventListener('click', ()=>{
    location.href="/perfume/write";
});

let perwrtbtn=document.querySelector("perwrtbtn");
let perwrtfrm=document.querySelector("#perwrtfrm");
perwrtbtn?.addEventListener('click', ()=>{
    if(perwrtfrm.name.value==="") {
        alert("향수명을 입력해주세요.")
    } else if (perwrtfrm.brand.value==="") {
        alert("브랜드를 입력해주세요.")
    } else if (perwrtfrm.volume.value==="") {
        alert("용량을 입력해주세요.")
    } else if (perwrtfrm.price.value==="") {
        alert("가격을 입력해주세요.")
    } else {
        perwrtfrm.method='post';
        perwrtfrm.enctype='multipart/form-data';
        perwrtfrm.submit();
        alert("작성이 완료되었습니다.")
    }
});
// 바로 결제하기, 장바구니 버튼
let paybtn = document.querySelector("#paybtn");
let cartbtn = document.querySelector("#cartbtn");
let cartmodal = document.querySelector("#cartmodal");
let cartgobtn = document.querySelector("#cartgobtn");
let shopbtn = document.querySelector("#shopbtn");
let modal = null;

paybtn?.addEventListener('click',()=> {

    location.href = "/order/payment";
});
cartbtn?.addEventListener('click',()=>{
    try{
        modal = new bootstrap.Modal(cartmodal, {});
    }catch(e){}
    modal.show();
});
shopbtn?.addEventListener('click',()=>{
   location.href = "/perfume/list/1"
});
cartgobtn?.addEventListener('click',()=>{
    let cartmodfrm = document.forms.cartmodfrm;
    cartmodfrm.method="post";
    cartmodfrm.action="/order/cart/enter/" + cartmodfrm.mno.value;
    cartmodfrm.submit();
    alert("상품이 장바구니에 담겼습니다.")


});
  
let cmtwrtbtn=document.querySelector("#cmtwrtbtn");
let cmtwrtfrm=document.querySelector("#cmtmodfrm")
cmtwrtbtn?.addEventListener('click', ()=>{
    if(cmtwrtfrm.comment.value === "") {
        alert("내용을 입력해주세요.")
    } else {
        cmtwrtfrm.method='post';
        cmtwrtfrm.action="/perfume/comment"
        cmtwrtfrm.submit();
        alert("작성이 완료되었습니다.")
    }
});

let qaawrtbtn=document.querySelector("#qaawrtbtn");
let qaatwrtfrm=document.querySelector("#qaamodfrm")
qaawrtbtn?.addEventListener('click', ()=>{
    if(qaatwrtfrm.question.value === "") {
        alert("내용을 입력해주세요.")
    } else {
        qaatwrtfrm.method='post';
        qaatwrtfrm.action="/perfume/question"
        qaatwrtfrm.submit();
        alert("작성이 완료되었습니다.")
    }
});

