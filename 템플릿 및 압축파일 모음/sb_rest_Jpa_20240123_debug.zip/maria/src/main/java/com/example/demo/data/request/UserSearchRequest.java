package com.example.demo.data.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserSearchRequest {
	
	private Integer id;
    private String name;
    private int age;
}
