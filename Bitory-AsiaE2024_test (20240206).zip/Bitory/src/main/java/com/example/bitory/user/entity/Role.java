package com.example.bitory.user.entity;

public enum Role {

    Common, Admin

}
