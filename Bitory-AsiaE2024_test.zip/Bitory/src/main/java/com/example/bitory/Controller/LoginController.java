package com.example.bitory.Controller;

import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/member")
@RequiredArgsConstructor
public class LoginController {

    Logger logger = LogManager.getLogger(IndexController.class);

    @GetMapping("/login")
    public String login() {
        logger.info("login 호출!");

        return "member/login";
    }
    


    }