package com.example.bitory.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@Controller
@RequestMapping("/member")
public class JoinController {


	
	@GetMapping("/join")
	public String join(){
		return "member/join";
	}

}
