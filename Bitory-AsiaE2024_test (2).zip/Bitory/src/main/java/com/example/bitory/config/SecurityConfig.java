package com.example.bitory.config;


public class SecurityConfig {

}
