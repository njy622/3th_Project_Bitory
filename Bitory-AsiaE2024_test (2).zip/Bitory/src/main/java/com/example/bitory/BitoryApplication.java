package com.example.bitory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitoryApplication.class, args);
	}


}
