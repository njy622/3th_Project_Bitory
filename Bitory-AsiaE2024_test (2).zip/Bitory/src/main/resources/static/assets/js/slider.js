var swiper = new Swiper('.swiper-container', {
      slidesPerView: 'auto',
      loop: true,
      pagination: {
        el: '.swiper-pagination',
      },
    });